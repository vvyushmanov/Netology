# Ansible Collection - my_own_namespace.yandex_cloud_elk

This collection focuses on testing self-written modules.
For more information please refer to the role documentation.
